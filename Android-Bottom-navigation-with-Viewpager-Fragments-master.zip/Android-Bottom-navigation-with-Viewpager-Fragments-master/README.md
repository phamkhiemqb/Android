# Android-Bottom-navigation-with-Viewpager-Fragments
 Android Bottom navigation with Viewpager Fragments explains how to use ViewPager with Android Studio Built in templet bottom navigation.  

<h1>Youtube</h1>
https://youtu.be/TVa1VnMXKzE

<h1>Screenshots</h1>
<img src="/sample1.png"/>

<img src="/sample2.png"/>
