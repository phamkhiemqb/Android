package com.example.admin.recyclerview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements MyAdapter.OnDeleteListener
{

    RecyclerView mRecyclerView;
    MyAdapter mAdapter;

    TextView txtName;

    ArrayList<String> arrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtName = (TextView)findViewById(R.id.activity_main_name);

        mRecyclerView = (RecyclerView)findViewById(R.id.activity_man_recycler);
        mRecyclerView.setLayoutManager(new GridLayoutManager(this,2));

        setData();

        mAdapter = new MyAdapter(this, arrayList, this);
        mRecyclerView.setAdapter(mAdapter);

    }

    private void setData(){
        arrayList.add("ABC");
        arrayList.add("DDDDDD");
        arrayList.add("RRRRRR");
        arrayList.add("ABC");
        arrayList.add("ABC");
        arrayList.add("ABC");
        arrayList.add("DDDDDD");
        arrayList.add("RRRRRR");

        arrayList.add("DDDDDD");
        arrayList.add("RRRRRR");
        arrayList.add("DDDDDD");
        arrayList.add("RRRRRR");
        arrayList.add("ABC");
        arrayList.add("ABC");
        arrayList.add("ABC");
    }

    @Override
    public void onDelete(String data) {
        txtName.setText(data);
    }
}
