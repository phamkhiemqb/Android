package com.example.admin.recyclerview;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.file.Path;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity implements MyAdapter.OnDeleteListener
{

    final String BASE_URL = "http://45.77.27.89:8088/api/";

    Retrofit retrofit;

    OnApiInterface myRetrofitAPI;


    RecyclerView mRecyclerView;
    MyAdapter mAdapter;

    TextView txtName;
    SwipeRefreshLayout swipeRefresh;
    ProgressBar mProgress;

    ArrayList<Salon> arrayList = new ArrayList<>();
    int page=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        swipeRefresh = (SwipeRefreshLayout)findViewById(R.id.swipelayout);

        txtName = (TextView)findViewById(R.id.activity_main_name);

        mRecyclerView = (RecyclerView)findViewById(R.id.activity_man_recycler);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mProgress = (ProgressBar)findViewById(R.id.progress);
      //  arrayList.addAll(setData(0));

        mAdapter = new MyAdapter(this, arrayList, this);
        mRecyclerView.setAdapter(mAdapter);

        retrofit = new Retrofit.Builder() .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) .build();

        myRetrofitAPI = retrofit.create(OnApiInterface.class);


        loadSalon(0);

        loadmore();

        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                page = 0;
                loadSalon(page);
                loadmore();
                swipeRefresh.setRefreshing(false);
            }
        });

    }

    private ArrayList<String> setData(int page){
         ArrayList<String> a= new ArrayList<>();
         for(int i=0;i<10;i++){
             a.add("ABC"+page+i);
         }
        return a;
    }

    @Override
    public void onDelete(String data) {
        txtName.setText(data);
    }

    private void loadmore(){
        mRecyclerView.addOnScrollListener(new EndlessRecyclerViewScrollListener((LinearLayoutManager)
                mRecyclerView.getLayoutManager()){
            @Override
            public void onLoadMore(int page, int totalItemsCount) {
               loadSalon(page);
            }

        });
    }

    private void loadSalon(final int page){
        if(page!=0) mProgress.setVisibility(View.VISIBLE);
        myRetrofitAPI.getListSalons(page).enqueue(new Callback<ListSalon>() {
            @Override
            public void onResponse(Call<ListSalon> call, Response<ListSalon> response) {
                mProgress.setVisibility(View.GONE);
                if(response.isSuccessful()) {
                    if(response.body()!=null){
                        if(page==0){
                            arrayList.clear();

                        }
                        arrayList.addAll(response.body().data);
                        mAdapter.notifyDataSetChanged();
                    }

                }else{
                    Toast.makeText(MainActivity.this, "error",Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ListSalon> call, Throwable t) {
                mProgress.setVisibility(View.GONE);
                Toast.makeText(MainActivity.this, "failed",Toast.LENGTH_SHORT).show();
            }
        });

    }
}
