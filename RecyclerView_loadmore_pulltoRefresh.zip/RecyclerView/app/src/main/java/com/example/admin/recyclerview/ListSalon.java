package com.example.admin.recyclerview;

import java.util.ArrayList;

public class ListSalon {
    ArrayList<Salon> data;

    public ArrayList<Salon> getData() {
        return data;
    }

    public void setData(ArrayList<Salon> data) {
        this.data = data;
    }
}
